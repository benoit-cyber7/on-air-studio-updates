"""ON AIR STUDIO Windows Bridge (experimental, native PortAudio I/O).
No network data leaves localhost. Import sounddevice only after environment setup.
"""
from __future__ import annotations
import json
import math
import os
import threading
import wave
from dataclasses import dataclass, asdict, replace
from pathlib import Path
from typing import Any
from native_dsp import VocalDSP

import numpy as np

RATE = 48000
BLOCK = 512
MAX_MUSIC_SECONDS = 12 * 60


def dbfs_peak(samples: np.ndarray) -> float | None:
    if samples.size == 0:
        return None
    clean = np.nan_to_num(samples, nan=0.0, posinf=0.0, neginf=0.0)
    peak = float(np.max(np.abs(clean)))
    return round(20.0 * math.log10(max(peak, 1e-12)), 1)


def limiter(x: np.ndarray, ceiling: float = 0.85) -> np.ndarray:
    # Deterministic sample-peak limiter, not a true-peak limiter.
    return np.clip(x, -ceiling, ceiling)


@dataclass(frozen=True)
class MixSettings:
    mic_channel: int = 1
    profile: str = 'chant'
    phone_voice: float = 0.70
    phone_music: float = 0.40
    monitor_voice: float = 0.0  # direct monitor on MiniFuse by default
    monitor_music: float = 0.40
    intro_phone: float = 0.55  # independent intro deck routed to phone bus only when unmuted
    intro_monitor: float = 0.40
    mute_phone: bool = True
    mute_monitor: bool = False
    compressor_threshold_db: float = -18.0
    compressor_ratio: float = 2.0
    mix_music: bool = True
    # These settings process native voice to both local buses, not browser audio.
    hpf_enabled: bool = True
    hpf_hz: float = 85.0
    eq_low_db: float = 0.0
    eq_mid_db: float = 1.0
    eq_high_db: float = 1.0
    deesser_enabled: bool = False
    deesser_amount: float = 0.5
    expander_enabled: bool = False
    expander_threshold_db: float = -52.0
    expander_ratio: float = 1.5
    reverb_mix: float = 0.10
    delay_mix: float = 0.0
    delay_bpm: float = 120.0


PRESETS = {
    'chant': dict(compressor_threshold_db=-18.0, compressor_ratio=2.0, eq_mid_db=1.0, reverb_mix=0.10, delay_mix=0.0),
    'rap': dict(compressor_threshold_db=-21.0, compressor_ratio=3.0, eq_mid_db=2.0, reverb_mix=0.04, delay_mix=0.0),
}


def compress_mono(voice: np.ndarray, threshold_db: float, ratio: float) -> np.ndarray:
    # Feed-forward smooth-ish envelope per block; conservative starting point.
    # This is a preliminary compressor, not a mastering-grade DSP.
    rms = float(np.sqrt(np.mean(np.square(voice, dtype=np.float64)) + 1e-15))
    rms_db = 20 * math.log10(max(rms, 1e-12))
    reduction_db = max(rms_db - threshold_db, 0) * (1 - 1 / max(1.0, ratio))
    gain = 10 ** (-reduction_db / 20)
    return (voice * gain).astype('float32', copy=False)


def resample_stereo(audio: np.ndarray, rate: int, out_rate: int = RATE) -> np.ndarray:
    if audio.ndim == 1:
        audio = np.column_stack((audio, audio))
    elif audio.shape[1] == 1:
        audio = np.repeat(audio, 2, axis=1)
    elif audio.shape[1] > 2:
        audio = audio[:, :2]
    audio = np.nan_to_num(audio.astype('float32', copy=False))
    if rate == out_rate:
        return audio
    # Resampling is done ONCE when loading a file, never in the audio callback.
    try:
        from scipy.signal import resample_poly
        from math import gcd
        d = gcd(rate, out_rate)
        return resample_poly(audio, out_rate // d, rate // d, axis=0).astype('float32')
    except ImportError:
        size = max(1, round(len(audio) * out_rate / rate))
        t = np.arange(size) * rate / out_rate
        base = np.arange(len(audio))
        return np.column_stack([np.interp(t, base, audio[:, i]) for i in range(2)]).astype('float32')


def decode_music(path: str | Path) -> np.ndarray:
    import soundfile as sf
    path = Path(path)
    if path.stat().st_size > 120 * 1024 * 1024:
        raise ValueError('Fichier trop volumineux (maximum 120 Mo).')
    data, rate = sf.read(str(path), dtype='float32', always_2d=True)
    if len(data) / rate > MAX_MUSIC_SECONDS:
        raise ValueError('Extrait trop long (12 minutes maximum).')
    return resample_stereo(data, rate)


def validate_devices(input_index: int, output_index: int, mic_channel: int = 1, sd: Any = None) -> dict:
    if sd is None:
        import sounddevice as sd
    idev = sd.query_devices(input_index)
    odev = sd.query_devices(output_index)
    hostapis = sd.query_hostapis()
    if idev['max_input_channels'] < mic_channel or mic_channel < 1:
        raise ValueError('Le canal micro demandé est indisponible.')
    if odev['max_output_channels'] < 4:
        raise ValueError('La sortie doit exposer au moins 4 canaux : 1/2 casque, 3/4 OTG.')
    ihost = hostapis[idev['hostapi']]['name']
    ohost = hostapis[odev['hostapi']]['name']
    if idev['hostapi'] != odev['hostapi']:
        raise ValueError('Choisis une entrée et une sortie du même pilote (ASIO/WASAPI).')
    return dict(input_name=idev['name'], output_name=odev['name'], host_api=ohost,
                input_channels=idev['max_input_channels'], output_channels=odev['max_output_channels'])


class NativeMixer:
    def __init__(self, sd: Any = None) -> None:
        self.sd = sd
        self.stream = None
        self.input_index: int | None = None
        self.output_index: int | None = None
        self.settings = MixSettings()
        self.music: np.ndarray | None = None
        self.music_position = 0
        self.music_playing = False
        self.source_filename = ''
        self.intro: np.ndarray | None = None
        self.intro_position = 0
        self.intro_playing = False
        self.intro_fade_frames = 0
        self.intro_fade_remaining = 0
        self.intro_name = ''
        self.intro_file_id = ''
        self.last_peak_dbfs: float | None = None
        self.last_phone_peak_dbfs: float | None = None
        self.xruns = 0
        self.error = ''
        self.device_info: dict | None = None
        self.blocks = 0
        self._envelope = 0.0
        self._previous_gain = 1.0
        self.dsp = VocalDSP(RATE)

    def api(self):
        if self.sd is None:
            import sounddevice as sd
            self.sd = sd
        return self.sd

    def devices(self) -> list[dict]:
        sd = self.api()
        host = sd.query_hostapis()
        result = []
        for i, d in enumerate(sd.query_devices()):
            if d['max_input_channels'] or d['max_output_channels']:
                result.append(dict(id=i, name=d['name'], api=host[d['hostapi']]['name'],
                                   inputs=d['max_input_channels'], outputs=d['max_output_channels'],
                                   default_samplerate=d['default_samplerate']))
        return result

    def set_settings(self, changes: dict) -> MixSettings:
        permitted = set(MixSettings.__dataclass_fields__.keys())
        if any(k not in permitted for k in changes):
            raise ValueError('Paramètre inconnu.')
        floats = ('phone_voice', 'phone_music', 'monitor_voice', 'monitor_music', 'intro_phone', 'intro_monitor')
        floats_range = dict(hpf_hz=(40,220), eq_low_db=(-12,12), eq_mid_db=(-12,12),
            eq_high_db=(-12,12),deesser_amount=(0,1), expander_threshold_db=(-75,-15),
            expander_ratio=(1,4), reverb_mix=(0,0.35), delay_mix=(0,0.35),delay_bpm=(55,220))
        for key,(lo,hi) in floats_range.items():
            if key in changes:
                try: val=float(changes[key])
                except (ValueError,TypeError):raise ValueError(f'{key} n’est pas un nombre valide.')
                if not math.isfinite(val) or not lo<=val<=hi: raise ValueError(f'{key} doit être entre {lo} et {hi}.')
                changes=dict(changes)
                changes[key]=val
        for key in ('hpf_enabled','deesser_enabled','expander_enabled'):
            if key in changes and not isinstance(changes[key],bool):
                raise ValueError(key+' doit être un booléen.')
        cleaned = dict(changes)
        for key in floats:
            if key in cleaned:
                v = float(cleaned[key])
                if not math.isfinite(v) or not 0 <= v <= 1:
                    raise ValueError(f'{key} doit être entre 0 et 1.')
                cleaned[key] = v
        if 'mic_channel' in cleaned:
            cleaned['mic_channel'] = int(cleaned['mic_channel'])
            if not 1 <= cleaned['mic_channel'] <= 16:
                raise ValueError('Canal micro invalide.')
            if self.stream is not None and cleaned['mic_channel'] != self.settings.mic_channel:
                raise ValueError('Arrête le moteur avant de changer de canal microphone.')
        if 'profile' in cleaned:
            if cleaned['profile'] not in PRESETS:
                raise ValueError('Profil inconnu.')
            # A preset supplies defaults; explicitly synchronized user sliders win.
            cleaned = {**PRESETS[cleaned['profile']], **cleaned}
        for k in ('mute_phone','mute_monitor','mix_music'):
            if k in cleaned and not isinstance(cleaned[k], bool):
                raise ValueError(k + ' doit être un booléen.')
        if 'compressor_ratio' in cleaned:
            try: val = float(cleaned['compressor_ratio'])
            except (ValueError,TypeError): raise ValueError('Ratio invalide.')
            if not math.isfinite(val) or not 1 <= val <= 8: raise ValueError('Ratio hors limites.')
            cleaned['compressor_ratio']=val
        if 'compressor_threshold_db' in cleaned:
            try: val = float(cleaned['compressor_threshold_db'])
            except (ValueError,TypeError): raise ValueError('Seuil invalide.')
            if not math.isfinite(val) or not -50 <= val <= 0: raise ValueError('Seuil hors limites.')
            cleaned['compressor_threshold_db']=val
        self.settings = replace(self.settings, **cleaned)
        return self.settings

    def load_music(self, path: str):
        music = decode_music(path)
        # Atomically replace; callback reads a consistent snapshot.
        self.music_playing = False
        self.music = music
        self.music_position = 0
        self.source_filename = Path(path).name
        return dict(frames=len(music), seconds=round(len(music)/RATE, 2), filename=self.source_filename)

    def load_intro(self, path: str | Path, event_name: str, file_id: str = '') -> dict:
        # Decoding runs outside the real-time callback; never auto-start playback.
        data = decode_music(path)
        self.intro_playing = False
        self.intro = data
        self.intro_position = 0
        self.intro_fade_frames = 0
        self.intro_fade_remaining = 0
        self.intro_name = event_name
        self.intro_file_id = file_id
        return dict(event=event_name, seconds=round(len(data) / RATE, 2), file_id=file_id)

    def intro_start(self) -> None:
        if self.intro is None:
            raise ValueError('Charge une intro avant de démarrer.')
        if self.stream is None:
            raise ValueError('Démarre le moteur Windows avec la MiniFuse pour envoyer l’intro aux sorties natives. Tu peux la préécouter dans le navigateur sans matériel.')
        if self.intro_position >= len(self.intro):
            self.intro_position = 0
        self.intro_fade_remaining = 0
        self.intro_fade_frames = 0
        self.music_playing = False  # avoid overlap with an instrumental on entry
        self.intro_playing = True

    def intro_stop(self) -> None:
        self.intro_playing = False
        self.intro_position = 0
        self.intro_fade_frames = 0
        self.intro_fade_remaining = 0

    def intro_fade_out(self, seconds: float = 4.0) -> None:
        if not self.intro_playing:
            raise ValueError('L’intro ne joue pas actuellement.')
        seconds = float(seconds)
        if not math.isfinite(seconds) or not 0.5 <= seconds <= 15:
            raise ValueError('Fondu entre 0,5 et 15 secondes.')
        self.intro_fade_frames = self.intro_fade_remaining = round(seconds * RATE)

    def intro_block(self, frames: int) -> np.ndarray:
        out = np.zeros((frames, 2), dtype=np.float32)
        src = self.intro
        if src is None or not self.intro_playing:
            return out
        start = self.intro_position
        stop = min(len(src), start + frames)
        n = max(0, stop - start)
        if n:
            out[:n] = src[start:stop]
        self.intro_position = stop
        if self.intro_fade_remaining > 0 and n:
            # Sample-accurate linear fade, independent of the musical bed.
            indices = np.arange(n, dtype=np.float32)
            gain = np.clip((self.intro_fade_remaining - indices) / max(1, self.intro_fade_frames), 0, 1)
            out[:n] *= gain[:, None]
            self.intro_fade_remaining = max(0, self.intro_fade_remaining - n)
            if self.intro_fade_remaining == 0:
                self.intro_stop()
        if stop >= len(src):
            self.intro_playing = False
        return out

    def music_block(self, frames: int) -> np.ndarray:
        buffer = self.music
        if buffer is None or not self.music_playing:
            return np.zeros((frames, 2), dtype=np.float32)
        start = self.music_position
        stop = min(len(buffer), start+frames)
        out = np.zeros((frames,2), dtype=np.float32)
        n = stop-start
        if n > 0: out[:n] = buffer[start:stop]
        self.music_position = stop
        if stop >= len(buffer): self.music_playing = False
        return out

    def mix_block(self, incoming: np.ndarray, frames: int) -> np.ndarray:
        settings = self.settings
        if incoming.ndim != 2 or incoming.shape[1] < settings.mic_channel:
            raise ValueError('Entrée microphone invalide')
        voice = np.clip(np.nan_to_num(incoming[:, settings.mic_channel-1].astype('float32', copy=False), nan=0.0, posinf=0.0, neginf=0.0), -1.0, 1.0)
        self.last_peak_dbfs = dbfs_peak(voice)
        # Native DSP applied before splitting to monitor and phone buses.
        treated = self.dsp.process(voice, settings)
        music = self.music_block(frames) if settings.mix_music else np.zeros((frames,2), np.float32)
        intro = self.intro_block(frames)  # independent event jingle deck
        out = np.zeros((frames,4), np.float32)
        if not settings.mute_monitor:
            out[:,0:2] = music * settings.monitor_music + intro * settings.intro_monitor + treated[:,None] * settings.monitor_voice
        if not settings.mute_phone:
            out[:,2:4] = music * settings.phone_music + intro * settings.intro_phone + treated[:,None] * settings.phone_voice
        # Status reflects the actual limited digital stream, never the iPhone.
        self.last_phone_peak_dbfs = dbfs_peak(limiter(out[:,2:4]))
        self.blocks += 1
        return limiter(out)

    def _callback(self, indata, outdata, frames, time_info, status):
        if status:
            self.xruns += 1
        try:
            outdata[:] = self.mix_block(indata, frames)
        except Exception as exc:
            outdata.fill(0)
            self.error = str(exc)
            self.xruns += 1

    def start(self, input_index: int, output_index: int) -> dict:
        if self.stream is not None:
            raise ValueError('Moteur déjà actif.')
        sd = self.api()
        self.device_info = validate_devices(input_index, output_index, self.settings.mic_channel, sd)
        if self.device_info['host_api'].lower().find('asio') < 0 and self.device_info['host_api'].lower().find('wasapi') < 0:
            raise ValueError('Utilise le pilote ASIO ou WASAPI sous Windows.')
        sd.check_input_settings(device=input_index, channels=self.settings.mic_channel, samplerate=RATE, dtype='float32')
        sd.check_output_settings(device=output_index, channels=4, samplerate=RATE, dtype='float32')
        self.input_index, self.output_index = input_index, output_index
        self.error, self.xruns, self.blocks = '', 0, 0
        self.dsp.reset()
        self.stream = sd.Stream(device=(input_index,output_index), samplerate=RATE,
                                blocksize=BLOCK, channels=(self.settings.mic_channel,4),
                                dtype='float32', callback=self._callback)
        try:
            self.stream.start()
        except Exception:
            self.stream.close(); self.stream=None; raise
        return self.status()

    def stop(self):
        s, self.stream = self.stream, None
        self.music_playing = False
        self.intro_playing = False
        self.last_peak_dbfs = None
        self.last_phone_peak_dbfs = None
        if s is not None:
            s.stop(); s.close()

    def status(self):
        return dict(running=self.stream is not None, input_index=self.input_index,
                    output_index=self.output_index, sample_rate=RATE, block_frames=BLOCK,
                    device=self.device_info, settings=asdict(self.settings),
                    music=dict(filename=self.source_filename, loaded=self.music is not None,
                               playing=self.music_playing,
                               seconds=round(len(self.music)/RATE,1) if self.music is not None else None),
                    intro=dict(event=self.intro_name, file_id=self.intro_file_id,
                               loaded=self.intro is not None, playing=self.intro_playing,
                               position_seconds=round(self.intro_position/RATE,1),
                               duration_seconds=round(len(self.intro)/RATE,1) if self.intro is not None else None,
                               fading=self.intro_fade_remaining>0),
                    input_peak_dbfs=self.last_peak_dbfs, phone_bus_peak_dbfs=self.last_phone_peak_dbfs,
                    callback_overruns=self.xruns, processed_blocks=self.blocks, error=self.error,
                    bigo_verified=False, native_driver_verified=bool(self.stream))


def simulated_local_roundtrip(delay_samples: int, rate: int = RATE) -> dict:
    """Unit-test helper: the 100%-known synthetic delay is NOT a hardware result."""
    sig = np.zeros(4096, dtype=np.float32); sig[100] = 0.03
    read = np.zeros(4096, dtype=np.float32); read[100+delay_samples] = 0.03
    lag = int(np.argmax(np.correlate(read, sig, mode='full')) - (len(sig)-1))
    return dict(samples=lag, ms=round(lag*1000/rate,3), synthetic=True)
