"""ON AIR STUDIO: vocal DSP for *local native output*, not a guarantee of BIGO reception.

48-kHz float32 mono, block-streaming processing, no network/cloud, no audio capture.
Processing: HPF -> 3-band parametric EQ -> sibilance reduction -> soft expander
-> smoothed compressor -> modest early reflections / timed echo.
These are deliberately conservative initial algorithms, not claims of studio mastering quality.
"""
from __future__ import annotations
import math
import numpy as np
from scipy.signal import butter, sosfilt, lfilter

RATE = 48000


def peaking(freq: float, gain_db: float, q: float = 0.75, rate: int = RATE):
    """RBJ Audio EQ Cookbook peaking biquad, normalized a0=1."""
    A = 10.0 ** (gain_db / 40.0)
    omega = 2 * math.pi * freq / rate
    alpha = math.sin(omega) / (2 * q)
    cosv = math.cos(omega)
    b = np.array([1+alpha*A, -2*cosv, 1-alpha*A], dtype=np.float64)
    a = np.array([1+alpha/A, -2*cosv, 1-alpha/A], dtype=np.float64)
    return b/a[0], a/a[0]


class VocalDSP:
    def __init__(self, rate: int = RATE):
        self.rate = rate
        self.filters = {}
        self.deesser_gain = 1.0
        self.expander_gain = 1.0
        self.compressor_gain = 1.0
        self.verb_ring = np.zeros(int(rate*.42), dtype=np.float32)
        self.echo_ring = np.zeros(int(rate*2.1), dtype=np.float32)
        self.verb_pos = 0
        self.echo_pos = 0
        self.samples = 0

    def reset(self):
        self.__init__(self.rate)

    def _filt(self, key, x, coeff, mode):
        # Recreate filter state only if parameters changed, not every audio callback.
        sig = tuple(np.asarray(coeff[0]).ravel().tolist()) + tuple(np.asarray(coeff[1]).ravel().tolist())
        old = self.filters.get(key)
        if old is None or old[0] != sig:
            state = np.zeros((1, 2), dtype=np.float64) if mode=='sos' else np.zeros(2, dtype=np.float64)
        else:
            state = old[1]
        if mode == 'sos':
            y,z = sosfilt(coeff[0], x.astype('float64'), zi=state)
        else:
            y,z = lfilter(coeff[0], coeff[1], x.astype('float64'), zi=state)
        self.filters[key]=(sig,z)
        return y.astype('float32',copy=False)

    @staticmethod
    def _ramp(last, target, frames):
        return np.linspace(last,target,frames,endpoint=True,dtype=np.float32)

    def process(self, voice: np.ndarray, s) -> np.ndarray:
        voice = np.nan_to_num(np.asarray(voice,dtype=np.float32), nan=0., posinf=0., neginf=0.)
        if voice.ndim != 1: raise ValueError('Le traitement vocal nécessite un signal mono.')
        frames = len(voice)
        if not frames: return voice.copy()
        x = voice.copy()
        if s.hpf_enabled:
            sos = butter(2, s.hpf_hz/(self.rate/2), 'highpass',output='sos')
            x = self._filt('hpf',x,(sos,np.array([1.])), 'sos')
        for name,freq in [('low',160),('mid',1600),('high',6500)]:
            gain = float(getattr(s, f'eq_{name}_db'))
            if abs(gain)>1e-7:
                b,a=peaking(freq,gain,rate=self.rate)
                x=self._filt(name,x,(b,a),'ba')
        if s.deesser_enabled and s.deesser_amount>0:
            # Detect energy on sibilant band and attenuate that band only.
            sos=butter(2,4700/(self.rate/2),'highpass',output='sos')
            high=self._filt('sibilant',x,(sos,np.array([1.])), 'sos')
            hf_rms=float(np.sqrt(np.mean(high.astype(np.float64)**2)+1e-12))
            hf_db=20*math.log10(max(hf_rms,1e-10))
            # Start reducing above -38 dBFS high-frequency energy, max 70% band reduction.
            target=1-min(.70, max(0,hf_db+38)*.035 * s.deesser_amount)
            ramp=self._ramp(self.deesser_gain,target,frames)
            x=x-high*(1-ramp)
            self.deesser_gain=target
        else:
            self.deesser_gain=1.0
        if s.expander_enabled:
            rms=float(np.sqrt(np.mean(x.astype(np.float64)**2)+1e-12))
            db=20*math.log10(max(rms,1e-10))
            attenuation=min(18.0,max(0,s.expander_threshold_db-db)*(s.expander_ratio-1))
            target=10**(-attenuation/20)
            x=x*self._ramp(self.expander_gain,target,frames)
            self.expander_gain=target
        else:
            self.expander_gain=1.0
        rms=float(np.sqrt(np.mean(x.astype(np.float64)**2)+1e-12))
        db=20*math.log10(max(rms,1e-10))
        red=max(db-s.compressor_threshold_db,0)*(1-1/max(1,s.compressor_ratio))
        target=10**(-red/20)
        x=x*self._ramp(self.compressor_gain,target,frames)
        self.compressor_gain=target
        dry=x.copy()
        # A small series of early reflections, not convolution reverb.
        if s.reverb_mix>0:
            offsets=[int(.057*self.rate),int(.093*self.rate),int(.157*self.rate)]
            taps=[.50,.30,.18]
            indices=(self.verb_pos+np.arange(frames))%len(self.verb_ring)
            wet=np.zeros(frames,dtype=np.float32)
            for offset,gain in zip(offsets,taps):
                wet+=gain*self.verb_ring[(indices-offset)%len(self.verb_ring)]
            self.verb_ring[indices]=dry
            self.verb_pos=(self.verb_pos+frames)%len(self.verb_ring)
            x=x*(1-s.reverb_mix)+wet*s.reverb_mix
        else:
            indices=(self.verb_pos+np.arange(frames))%len(self.verb_ring)
            self.verb_ring[indices]=dry
            self.verb_pos=(self.verb_pos+frames)%len(self.verb_ring)
        if s.delay_mix>0:
            # Note-synced eighth-note delay, simple 2-tap echo, no feedback loop.
            offset=max(1,int(self.rate*30/s.delay_bpm))
            idx=(self.echo_pos+np.arange(frames))%len(self.echo_ring)
            wet=(.70*self.echo_ring[(idx-offset)%len(self.echo_ring)]
                 +.25*self.echo_ring[(idx-2*offset)%len(self.echo_ring)])
            self.echo_ring[idx]=dry
            self.echo_pos=(self.echo_pos+frames)%len(self.echo_ring)
            x=x*(1-s.delay_mix)+wet*s.delay_mix
        else:
            idx=(self.echo_pos+np.arange(frames))%len(self.echo_ring)
            self.echo_ring[idx]=dry
            self.echo_pos=(self.echo_pos+frames)%len(self.echo_ring)
        self.samples+=frames
        return np.nan_to_num(x.astype('float32'), nan=0, posinf=0, neginf=0)
