"""Private ON AIR STUDIO bridge server. No external networking or telemetry."""
from __future__ import annotations
import json
import logging
import os
import tempfile
import shutil
import hashlib
import uuid
import re
import mimetypes
from datetime import datetime, timezone
from urllib.parse import unquote, parse_qs
import threading
import webbrowser
from dataclasses import asdict
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import numpy as np

from engine import NativeMixer, RATE, BLOCK

BASE = Path(__file__).resolve().parent
APPDATA = Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'ON_AIR_STUDIO'
UPLOADS = APPDATA / 'musique'
INTROS = APPDATA / 'intros'
INTRO_INDEX = INTROS / 'bibliotheque.json'
INTRO_SUFFIXES = {'.mp3', '.wav', '.flac', '.ogg'}
HOST = '127.0.0.1'
PORT = 18768
mixer = NativeMixer()
lock = threading.RLock()


def save_native_settings() -> dict:
    """Save only mixer preferences; never the audio recording or any verification flags.
    The OTG safety mute is always restored to ON after an application restart.
    """
    cfg=APPDATA/'native_mixer_settings.json'
    cfg.parent.mkdir(parents=True,exist_ok=True)
    values=asdict(mixer.settings)
    values['mute_phone']=True
    with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=cfg.parent,
                                     prefix='native_settings_',suffix='.tmp',delete=False) as f:
        temp_name=f.name
        json.dump({'schema':1,'settings':values},f,ensure_ascii=False,allow_nan=False)
    try:
        os.replace(temp_name,cfg)
    finally:
        if os.path.exists(temp_name):os.unlink(temp_name)
    return {'saved':True,'otg_will_restart_muted':True}


def load_native_settings() -> dict:
    cfg=APPDATA/'native_mixer_settings.json'
    if not cfg.is_file():raise ValueError('Aucun réglage natif sauvegardé.')
    if cfg.stat().st_size>10000:raise ValueError('Fichier de réglages trop volumineux.')
    payload=json.loads(cfg.read_text(encoding='utf-8'))
    if payload.get('schema')!=1 or not isinstance(payload.get('settings'),dict):
        raise ValueError('Sauvegarde incompatible ou invalide.')
    values=dict(payload['settings'])
    values['mute_phone']=True  # Always require an explicit live-authorisation click.
    mixer.set_settings(values)
    return {'restored':True,'otg_muted':mixer.settings.mute_phone,'settings':asdict(mixer.settings)}


def measure_local_roundtrip(input_index: int, output_index: int, sd=None) -> dict:
    """Physical line-out 1 -> input 2 patch cable test, NOT phone/OTG latency.
    Must never run while normal streaming. No result reported unless correlation is strong.
    """
    from engine import validate_devices
    if sd is None:
        import sounddevice as sd
    info = validate_devices(input_index,output_index,2,sd)
    if mixer.stream is not None:
        raise ValueError('Arrête le moteur avant la mesure de boucle.')
    frames = RATE * 2
    burst_length = 480
    pulse = (0.025 * np.sin(2*np.pi*997*np.arange(burst_length)/RATE) * np.hanning(burst_length)).astype('float32')
    output = np.zeros((frames,4),dtype='float32')
    pulse_start=4096
    output[pulse_start:pulse_start+burst_length,0]=pulse
    captured=np.zeros(frames,dtype='float32')
    offset=0
    def callback(indata,outdata,count,timestamp,status):
        nonlocal offset
        end=min(frames,offset+count)
        n=end-offset
        outdata.fill(0)
        if n>0:
            outdata[:n]=output[offset:end]
            captured[offset:end]=indata[:n,1]
        offset=end
        if offset >= frames:
            raise sd.CallbackStop()
    with sd.Stream(device=(input_index,output_index),samplerate=RATE,channels=(2,4),
                   dtype='float32',blocksize=BLOCK,callback=callback) as stream:
        import time
        deadline=time.monotonic()+5.0
        while stream.active and time.monotonic()<deadline:
            time.sleep(.02)
    # Compare recorded input 2 against known low-level test pulse.
    window=captured[pulse_start:pulse_start+int(.5*RATE)+burst_length]
    if len(window)<burst_length:
        raise ValueError('Enregistrement incomplet.')
    correlation=np.correlate(window,pulse,'valid')
    best=int(np.argmax(np.abs(correlation)))
    strength=abs(float(correlation[best]))
    captured_segment=window[best:best+burst_length]
    norm=float(np.linalg.norm(captured_segment)*np.linalg.norm(pulse)+1e-12)
    confidence=strength/norm
    if confidence < .65 or float(np.max(abs(captured_segment))) < .002:
        return {'measured': False, 'reason':'Impulsion non détectée. Vérifie le câble physique sortie 1 → entrée 2 et le niveau du gain.', 'phone_verified':False}
    return {'measured':True,'local_roundtrip_ms':round(best*1000/RATE,2),
            'correlation':round(confidence,3),'sample_rate':RATE,
            'scope':'Boucle physique sortie analogique 1 → entrée 2 ; PAS la latence iPhone/BIGO',
            'phone_verified':False}


def list_intros() -> list[dict]:
    if not INTRO_INDEX.exists():
        return []
    if INTRO_INDEX.stat().st_size > 100_000:
        raise ValueError('Bibliothèque d’intros invalide.')
    data=json.loads(INTRO_INDEX.read_text(encoding='utf-8'))
    if not isinstance(data, list):
        raise ValueError('Index des intros invalide.')
    return [x for x in data if isinstance(x,dict) and
            re.fullmatch(r'[0-9a-f]{32}',str(x.get('id',''))) and
            str(x.get('ext','')) in INTRO_SUFFIXES]


def store_intros(items: list[dict]) -> None:
    INTROS.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=INTROS,
                                     prefix='intro_library_',suffix='.tmp',delete=False) as f:
        temp=f.name
        json.dump(items,f,ensure_ascii=False,allow_nan=False)
    try: os.replace(temp,INTRO_INDEX)
    finally:
        if os.path.exists(temp):os.unlink(temp)


def intro_file(item: dict) -> Path:
    return INTROS / (item['id'] + item['ext'])

# Musique fournie par le créateur et incluse dans l'installation.
# Le premier démarrage la place dans la bibliothèque locale sans toucher aux
# autres intros. Sa lecture et sa diffusion ne démarrent jamais automatiquement.
OFFICIAL_INTRO = BASE / 'assets' / 'Entree_Star_Voice.mp3'
OFFICIAL_INTRO_SHA256 = 'c977d2f245e690a08aeac5dfd7cf65e665db2990b28506b7476aec8593c9a4b3'
OFFICIAL_INTRO_ID = 'c977d2f245e690a08aeac5dfd7cf65e6'


def install_official_intro() -> dict | None:
    """Initialisation non destructive et idempotente de l'intro Star Voice."""
    marker = INTROS / '.intro_star_voice_initialisee'
    if marker.exists():
        return next((i for i in list_intros() if i['id'] == OFFICIAL_INTRO_ID), None)
    if not OFFICIAL_INTRO.is_file():
        logging.warning('Musique officielle absente du paquet. Bibliothèque inchangée.')
        return None
    digest = hashlib.sha256(OFFICIAL_INTRO.read_bytes()).hexdigest()
    if digest != OFFICIAL_INTRO_SHA256:
        logging.warning('Empreinte de la musique officielle invalide. Aucun import.')
        return None
    existing = list_intros()
    item = next((i for i in existing if i['id'] == OFFICIAL_INTRO_ID), None)
    if item is None:
        if len(existing) >= 30:
            logging.warning('Bibliothèque pleine. Import de la musique officielle ignoré.')
            return None
        import soundfile as sf
        information = sf.info(str(OFFICIAL_INTRO))
        if information.duration <= 0 or information.duration > 12 * 60:
            raise ValueError('Musique officielle non prise en charge.')
        INTROS.mkdir(parents=True, exist_ok=True)
        target = intro_file({'id': OFFICIAL_INTRO_ID, 'ext': '.mp3'})
        with tempfile.NamedTemporaryFile(dir=INTROS, suffix='.mp3', delete=False) as f:
            temp = f.name
        try:
            shutil.copyfile(OFFICIAL_INTRO, temp)
            os.replace(temp, target)
            item = {'id': OFFICIAL_INTRO_ID,
                    'name': 'Entrée Star Voice · Intro des événements',
                    'filename': 'Entrée Star Voice.mp3',
                    'ext': '.mp3',
                    'duration_seconds': round(information.duration, 2),
                    'created_at': datetime.now(timezone.utc).isoformat(timespec='seconds')}
            store_intros(existing + [item])
        finally:
            if os.path.exists(temp): os.unlink(temp)
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text('Intro officielle initialisée ; suppression volontaire respectée.\n', encoding='utf-8')
    return item


class Handler(BaseHTTPRequestHandler):
    server_version='ONAirStudioLocal/1.0'
    def log_message(self,fmt,*args):
        logging.info(fmt,*args)
    def _valid_host(self):
        h=self.headers.get('Host','')
        return h in (f'{HOST}:{PORT}', HOST)
    def _valid_origin(self):
        origin=self.headers.get('Origin')
        # Browsers send Origin on POSTs. Reject cross-origin and untrusted browser forms.
        return origin == f'http://{HOST}:{PORT}'
    def _headers(self, code=200, content_type='application/json; charset=utf-8'):
        self.send_response(code)
        self.send_header('Content-Type',content_type)
        self.send_header('Cache-Control','no-store')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Content-Security-Policy',"default-src 'self' 'unsafe-inline' data: blob:; connect-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:;")
        self.end_headers()
    def _json(self, data,code=200):
        raw=json.dumps(data,ensure_ascii=False,allow_nan=False).encode('utf-8')
        self._headers(code)
        self.wfile.write(raw)
    def do_GET(self):
        if not self._valid_host(): self._json({'error':'Hôte refusé'},403);return
        path=urlparse(self.path).path
        if path == '/assets/Entree_Star_Voice.mp3':
            if not OFFICIAL_INTRO.is_file():
                self._json({'error':'Intro officielle absente'},404);return
            self.send_response(200)
            self.send_header('Content-Type','audio/mpeg')
            self.send_header('Content-Length',str(OFFICIAL_INTRO.stat().st_size))
            self.end_headers()
            try:
                with OFFICIAL_INTRO.open('rb') as source:shutil.copyfileobj(source,self.wfile)
            except (BrokenPipeError,ConnectionResetError):pass
        elif path == '/intro':
            self._headers(200,'text/html; charset=utf-8')
            self.wfile.write((BASE/'intro_panel.html').read_bytes())
        elif path == '/native':
            self._headers(200,'text/html; charset=utf-8')
            self.wfile.write((BASE/'native_panel.html').read_bytes())
        elif path in ('/','/studio'):
            self._headers(200,'text/html; charset=utf-8')
            self.wfile.write((BASE/'ON_AIR_STUDIO_OFFICIEL.html').read_bytes())
        elif path=='/api/health':
            self._json({'app':'on-air-studio-minifuse','project_disk_backup':False})
        elif path=='/api/devices':
            try:self._json({'devices':mixer.devices()})
            except Exception as e:self._json({'error':str(e)},500)
        elif path=='/api/status':self._json(mixer.status())
        elif path=='/api/intro/list':
            try: self._json({'items':list_intros(), 'intro':mixer.status()['intro']})
            except Exception as e:self._json({'error':str(e)},500)
        elif path=='/api/intro/file':
            try:
                file_id=parse_qs(urlparse(self.path).query).get('id',[''])[0]
                item=next((v for v in list_intros() if v['id']==file_id),None)
                if not item:raise FileNotFoundError('Intro inconnue.')
                fpath=intro_file(item)
                if not fpath.is_file():raise FileNotFoundError('Fichier intro absent.')
                total=fpath.stat().st_size;lo=0;hi=total-1
                range_header=self.headers.get('Range','')
                if range_header:
                    m=re.fullmatch(r'bytes=(\d*)-(\d*)',range_header)
                    if not m:raise ValueError('Plage de lecture invalide.')
                    if m.group(1):
                        lo=int(m.group(1));hi=min(int(m.group(2)),hi) if m.group(2) else hi
                    elif m.group(2):
                        lo=max(0,total-int(m.group(2)))
                    if lo>=total or hi<lo:raise ValueError('Plage hors fichier.')
                size=hi-lo+1
                self.send_response(206 if range_header else 200)
                self.send_header('Content-Type',mimetypes.guess_type(fpath.name)[0] or 'application/octet-stream')
                self.send_header('Accept-Ranges','bytes')
                self.send_header('Content-Length',str(size))
                self.send_header('Cache-Control','private, no-store')
                self.send_header('X-Content-Type-Options','nosniff')
                if range_header:self.send_header('Content-Range',f'bytes {lo}-{hi}/{total}')
                self.end_headers()
                with fpath.open('rb') as f:
                    f.seek(lo)
                    remaining=size
                    while remaining:
                        chunk=f.read(min(65536,remaining))
                        if not chunk:break
                        self.wfile.write(chunk);remaining-=len(chunk)
            except (ValueError,FileNotFoundError) as e:self._json({'error':str(e)},404)
            except (BrokenPipeError, ConnectionResetError):pass
        else:self._json({'error':'Page inconnue'},404)

    def do_POST(self):
        if not self._valid_host() or not self._valid_origin():
            self._json({'error':'Accès non autorisé (origine).'},403);return
        path=urlparse(self.path).path
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length>125*1024*1024: raise ValueError('Fichier trop grand.')
            if path=='/api/intro/upload':
                if length<1:raise ValueError('Aucun fichier audio.')
                name=Path(unquote(self.headers.get('X-Filename','intro.mp3'))).name
                ext=Path(name).suffix.lower()
                if ext not in INTRO_SUFFIXES:
                    raise ValueError('Utilise une intro MP3, WAV, FLAC ou OGG.')
                event=unquote(self.headers.get('X-Intro-Name','')).strip()[:72]
                if not event:raise ValueError('Indique le nom de ton événement.')
                existing=list_intros()
                if len(existing)>=30:raise ValueError('Bibliothèque pleine (30 intros). Supprime une intro inutilisée.')
                if length>120*1024*1024:raise ValueError('Fichier trop volumineux (120 Mo maximum).')
                INTROS.mkdir(parents=True,exist_ok=True)
                with tempfile.NamedTemporaryFile(dir=INTROS,suffix=ext,delete=False) as fp:
                    temp=fp.name;remaining=length
                    while remaining:
                        buf=self.rfile.read(min(65536,remaining))
                        if not buf:raise ValueError('Transfert incomplet.')
                        fp.write(buf);remaining-=len(buf)
                try:
                    from engine import decode_music
                    decoded=decode_music(temp)
                    ident=uuid.uuid4().hex
                    target=INTROS/(ident+ext)
                    item={'id':ident,'name':event,'filename':name,'ext':ext,
                          'duration_seconds':round(len(decoded)/RATE,2),
                          'created_at':datetime.now(timezone.utc).isoformat(timespec='seconds')}
                    with lock:
                        existing=list_intros()
                        if len(existing)>=30:raise ValueError('Bibliothèque pleine (30 intros).')
                        os.replace(temp,target)
                        try:store_intros(existing+[item])
                        except Exception:
                            target.unlink(missing_ok=True)
                            raise
                        mixer.load_intro(target,event,ident)
                    self._json({'ok':True,'item':item,'intro':mixer.status()['intro']})
                finally:
                    if os.path.exists(temp):os.unlink(temp)
                return
            if path=='/api/music':
                if length<1:raise ValueError('Aucun fichier.')
                name=Path(self.headers.get('X-Filename','musique.wav')).name
                if Path(name).suffix.lower() not in ('.wav','.flac','.ogg'):
                    raise ValueError('Utilise un fichier WAV, FLAC ou OGG.')
                UPLOADS.mkdir(parents=True,exist_ok=True)
                target=UPLOADS / ('extrait_charge' + Path(name).suffix.lower())
                with tempfile.NamedTemporaryFile(dir=UPLOADS,suffix='.tmp',delete=False) as fp:
                    remaining=length
                    while remaining:
                        block=self.rfile.read(min(65536,remaining))
                        if not block:raise ValueError('Envoi interrompu')
                        fp.write(block);remaining-=len(block)
                    temp=fp.name
                try:
                    # decoding validation first, atomic overwrite afterwards
                    with lock:
                        mixer.music_playing=False
                        from engine import decode_music
                        decoded=decode_music(temp)
                        os.replace(temp,target)
                        mixer.music=decoded;mixer.music_position=0;mixer.source_filename=name
                    self._json({'ok':True,'filename':name,'duration_seconds':round(len(decoded)/RATE,2)})
                finally:
                    if os.path.exists(temp):os.unlink(temp)
                return
            if length > 16384:raise ValueError('Requête trop longue')
            args=json.loads(self.rfile.read(length) or b'{}')
            with lock:
                if path=='/api/start':
                    result=mixer.start(int(args['input_index']),int(args['output_index']))
                elif path=='/api/stop':
                    mixer.stop();result=mixer.status()
                elif path=='/api/settings':
                    mixer.set_settings(args);result=mixer.status()
                elif path=='/api/settings/save':
                    result=save_native_settings()
                elif path=='/api/settings/load':
                    load_native_settings()
                    result=mixer.status()
                elif path=='/api/intro/select':
                    ident=str(args.get('id',''))
                    item=next((i for i in list_intros() if i['id']==ident),None)
                    if item is None:raise ValueError('Intro introuvable.')
                    result=mixer.load_intro(intro_file(item),item['name'],ident)
                elif path=='/api/intro/delete':
                    ident=str(args.get('id',''))
                    existing=list_intros()
                    item=next((i for i in existing if i['id']==ident),None)
                    if item is None:raise ValueError('Intro introuvable.')
                    if mixer.intro_file_id==ident:
                        mixer.intro_stop();mixer.intro=None;mixer.intro_name='';mixer.intro_file_id=''
                    store_intros([i for i in existing if i['id']!=ident])
                    intro_file(item).unlink(missing_ok=True)
                    result={'deleted':True}
                elif path=='/api/intro/play':
                    if bool(args.get('playing',True)):
                        mixer.intro_start()
                    else:
                        mixer.intro_playing=False
                    result=mixer.status()
                elif path=='/api/intro/stop':
                    mixer.intro_stop();result=mixer.status()
                elif path=='/api/intro/fade':
                    mixer.intro_fade_out(float(args.get('seconds',4)))
                    result=mixer.status()
                elif path=='/api/music/play':
                    if mixer.music is None:raise ValueError('Charge d’abord une instrumentale.')
                    mixer.music_playing=bool(args.get('playing',True));result=mixer.status()
                elif path=='/api/music/rewind':
                    mixer.music_position=0;result=mixer.status()
                elif path=='/api/latency':
                    if args.get('patch_confirmed') is not True:
                        raise ValueError('Confirme le câble physique et coupe tes enceintes avant le test.')
                    result=measure_local_roundtrip(int(args['input_index']),int(args['output_index']),mixer.api())
                else:self._json({'error':'Action inconnue'},404);return
            self._json({'ok':True,'result':result})
        except Exception as e:
            self._json({'error':str(e)},400)


def main():
    import argparse
    parser=argparse.ArgumentParser(description='ON AIR STUDIO - bridge Windows local')
    parser.add_argument('--no-browser', action='store_true')
    args=parser.parse_args()
    logging.basicConfig(level=logging.WARNING)
    # Précharge l'intro officielle pour une sélection immédiate, jamais pour la jouer.
    try:
        intro = install_official_intro()
        if intro:
            mixer.load_intro(intro_file(intro), intro['name'], intro['id'])
            print('Intro Star Voice intégrée à la bibliothèque (lecture désactivée).')
    except Exception as exc:
        logging.warning('Initialisation de l’intro impossible : %s', exc)
    if os.name != 'nt':
        print('AVERTISSEMENT : application prévue pour Windows; autres OS non validés.')
    try:
        server=ThreadingHTTPServer((HOST,PORT),Handler)
    except OSError as exc:
        print('Impossible de démarrer le serveur local :',exc);return 1
    print(f'ON AIR STUDIO - application reunie : http://{HOST}:{PORT}/')
    print('Prêt pour la configuration; aucun son envoyé tant que le moteur ne démarre pas.')
    if not args.no_browser:
        threading.Timer(.5,lambda:webbrowser.open(f'http://{HOST}:{PORT}/')).start()
    try:server.serve_forever()
    except KeyboardInterrupt:pass
    finally:
        mixer.stop();server.server_close()
    return 0

if __name__=='__main__':raise SystemExit(main())
